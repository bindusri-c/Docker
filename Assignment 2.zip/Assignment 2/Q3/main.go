package main

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"strconv"
	"sync"
	"time"

	pb "example.com/raftdemo/raftpb"
	"google.golang.org/grpc"
)

type State string

const (
	Follower  State = "Follower"
	Candidate State = "Candidate"
	Leader    State = "Leader"
)

type RaftNode struct {
	pb.UnimplementedRaftServiceServer
	id          string
	state       State
	currentTerm int32
	votedFor    string
	peers       []string
	mu          sync.Mutex

	voteCount        int
	electionResetEvt chan bool
}

func NewRaftNode(id string, peers []string) *RaftNode {
	return &RaftNode{
		id:               id,
		state:            Follower,
		currentTerm:      0,
		votedFor:         "",
		peers:            peers,
		electionResetEvt: make(chan bool),
	}
}

func (rn *RaftNode) RequestVote(ctx context.Context, req *pb.RequestVoteRequest) (*pb.RequestVoteResponse, error) {
	rn.mu.Lock()
	defer rn.mu.Unlock()

	fmt.Printf("Node %s runs RPC RequestVote called by Node %s\n", rn.id, req.CandidateId)

	if req.Term > rn.currentTerm {
		rn.currentTerm = req.Term
		rn.votedFor = ""
		rn.state = Follower
	}

	voteGranted := false
	if req.Term == rn.currentTerm && (rn.votedFor == "" || rn.votedFor == req.CandidateId) {
		voteGranted = true
		rn.votedFor = req.CandidateId
		rn.electionResetEvt <- true
	}

	return &pb.RequestVoteResponse{
		Term:        rn.currentTerm,
		VoteGranted: voteGranted,
	}, nil
}

func (rn *RaftNode) AppendEntries(ctx context.Context, req *pb.AppendEntriesRequest) (*pb.AppendEntriesResponse, error) {
	rn.mu.Lock()
	defer rn.mu.Unlock()

	fmt.Printf("Node %s runs RPC AppendEntries called by Node %s\n", rn.id, req.LeaderId)

	if req.Term >= rn.currentTerm {
		rn.currentTerm = req.Term
		rn.state = Follower
		rn.votedFor = ""
		rn.electionResetEvt <- true
		return &pb.AppendEntriesResponse{
			Term:    rn.currentTerm,
			Success: true,
		}, nil
	}

	return &pb.AppendEntriesResponse{
		Term:    rn.currentTerm,
		Success: false,
	}, nil
}

func (rn *RaftNode) startElection(peers []pb.RaftServiceClient) {
	rn.mu.Lock()
	rn.state = Candidate
	rn.currentTerm++
	rn.votedFor = rn.id
	rn.voteCount = 1
	termStarted := rn.currentTerm
	rn.mu.Unlock()

	fmt.Printf("Node %s became Candidate for term %d\n", rn.id, termStarted)

	for _, peer := range peers {
		go func(p pb.RaftServiceClient) {
			req := &pb.RequestVoteRequest{
				Term:        termStarted,
				CandidateId: rn.id,
			}

			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()

			resp, err := p.RequestVote(ctx, req)
			if err == nil {
				rn.mu.Lock()
				defer rn.mu.Unlock()

				if rn.state != Candidate || rn.currentTerm != termStarted {
					return
				}

				if resp.VoteGranted {
					rn.voteCount++
					if rn.voteCount > len(rn.peers)/2 {
						rn.state = Leader
						fmt.Printf("Node %s became Leader for term %d\n", rn.id, rn.currentTerm)
						rn.electionResetEvt <- true
					}
				} else if resp.Term > rn.currentTerm {
					rn.state = Follower
					rn.currentTerm = resp.Term
					rn.votedFor = ""
				}
			}
		}(peer)
	}
}

func (rn *RaftNode) sendHeartbeats(peers []pb.RaftServiceClient) {
	for _, peer := range peers {
		go func(p pb.RaftServiceClient) {
			req := &pb.AppendEntriesRequest{
				Term:     rn.currentTerm,
				LeaderId: rn.id,
			}

			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()

			_, _ = p.AppendEntries(ctx, req)
			fmt.Printf("Node %s sends RPC AppendEntries to peer\n", rn.id)
		}(peer)
	}
}

func (rn *RaftNode) runServer(port string) {
	lis, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("Failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	pb.RegisterRaftServiceServer(grpcServer, rn)
	fmt.Printf("Node %s started server on port %s\n", rn.id, port)
	grpcServer.Serve(lis)
}

func main() {
	nodeID := os.Getenv("NODE_ID")
	port := os.Getenv("PORT")
	totalNodes := 5

	var peers []string
	for i := 1; i <= totalNodes; i++ {
		peerID := "node" + strconv.Itoa(i)
		if peerID != nodeID {
			peers = append(peers, fmt.Sprintf("%s:500%d", peerID, i))
		}
	}

	rn := NewRaftNode(nodeID, peers)
	go rn.runServer(port)

	time.Sleep(2 * time.Second) // allow all servers to start

	var clients []pb.RaftServiceClient
	for _, addr := range rn.peers {
		conn, err := grpc.Dial(addr, grpc.WithInsecure())
		if err != nil {
			continue
		}
		clients = append(clients, pb.NewRaftServiceClient(conn))
	}

	for {
		timeout := time.Duration(1500+rand.Intn(1500)) * time.Millisecond
		timer := time.NewTimer(timeout)

		select {
		case <-timer.C:
			rn.mu.Lock()
			if rn.state != Leader {
				rn.mu.Unlock()
				rn.startElection(clients)
			} else {
				rn.mu.Unlock()
			}
		case <-rn.electionResetEvt:
			timer.Stop()
			if rn.state == Leader {
				go rn.sendHeartbeats(clients)
				time.Sleep(1 * time.Second)
			}
		}
	}
}
