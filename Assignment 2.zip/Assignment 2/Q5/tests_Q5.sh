#!/bin/bash

echo "Switching to Q4 folder..."
cd ../Q4 || { echo 'Folder not found!'; exit 1; }

echo "Starting Raft cluster..."
docker-compose up -d
sleep 5

echo "Sending command to leader (node1)..."
docker exec -i $(docker ps -qf "name=node1") python3 -c "
import grpc
import raft_log_pb2
import raft_log_pb2_grpc

channel = grpc.insecure_channel('node1:5001')
stub = raft_log_pb2_grpc.RaftLogServiceStub(channel)
response = stub.ClientCommand(raft_log_pb2.ClientRequest(command='SET x=10'))
print('Response:', response.message)
"

echo "Waiting for logs to propagate..."
sleep 5

echo "Capturing logs..."
mkdir -p ../Q5/logs
docker-compose logs node1 > ../Q5/logs/node1.log
docker-compose logs node2 > ../Q5/logs/node2.log
docker-compose logs node3 > ../Q5/logs/node3.log
docker-compose logs node4 > ../Q5/logs/node4.log
docker-compose logs node5 > ../Q5/logs/node5.log

echo "Stopping cluster..."
docker-compose down

echo "Logs captured in ../Q5/logs/"
