import grpc
import two_pc_pb2
import two_pc_pb2_grpc

PARTICIPANTS = {
    "P1": "participant1:5001",
    "P2": "participant2:5002",
    "P3": "participant3:5003",
    "P4": "participant4:5004",
}

def request_votes(transaction_id):
    votes = {}
    for pid, addr in PARTICIPANTS.items():
        with grpc.insecure_channel(addr) as channel:
            stub = two_pc_pb2_grpc.VotingPhaseStub(channel)
            print(f"[Coordinator] Sending vote request to {pid}")
            response = stub.RequestVote(two_pc_pb2.VoteRequest(transaction_id=transaction_id))
            votes[pid] = response.vote
            print(f"[Coordinator] Received {['COMMIT', 'ABORT'][response.vote]} from {pid}")
    return votes

if __name__ == '__main__':
    votes = request_votes("tx123")
    print("[Coordinator] Final Votes:", votes)
