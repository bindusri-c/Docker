import grpc
from concurrent import futures
import time
import random
import two_pc_pb2
import two_pc_pb2_grpc

class ParticipantService(two_pc_pb2_grpc.VotingPhaseServicer):
    def __init__(self, participant_id):
        self.participant_id = participant_id

    def RequestVote(self, request, context):
        vote = random.choice([two_pc_pb2.VoteResponse.COMMIT, two_pc_pb2.VoteResponse.ABORT])
        print(f"[Participant {self.participant_id}] Received vote request for transaction {request.transaction_id}. Voting: {'COMMIT' if vote == 0 else 'ABORT'}")
        return two_pc_pb2.VoteResponse(participant_id=self.participant_id, vote=vote)

def serve(participant_id, port):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    two_pc_pb2_grpc.add_VotingPhaseServicer_to_server(ParticipantService(participant_id), server)
    server.add_insecure_port(f"[::]:{port}")
    server.start()
    print(f"Participant {participant_id} running on port {port}")
    server.wait_for_termination()

if __name__ == '__main__':
    import sys
    serve(sys.argv[1], int(sys.argv[2]))
