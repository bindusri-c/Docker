import grpc
import time
import threading
import random
import sys
import os
from concurrent import futures

import raft_log_pb2
import raft_log_pb2_grpc

class RaftNode(raft_log_pb2_grpc.RaftLogServiceServicer):
    def __init__(self, node_id, peers):
        self.node_id = node_id
        self.peers = peers
        self.term = 0
        self.log = []
        self.commit_index = -1
        self.is_leader = False
        self.leader_id = None

    def AppendEntries(self, request, context):
        print(f"Node {self.node_id} runs RPC AppendEntries called by Node {request.leader_id}")
        if request.term >= self.term:
            self.term = request.term
            self.leader_id = request.leader_id
            self.log = list(request.entries)
            self.commit_index = request.commit_index
            print(f"[Node {self.node_id}] Log updated to index {self.commit_index}")
            return raft_log_pb2.AppendEntriesResponse(term=self.term, success=True)
        else:
            return raft_log_pb2.AppendEntriesResponse(term=self.term, success=False)

    def ClientCommand(self, request, context):
        if not self.is_leader:
            return raft_log_pb2.ClientResponse(message=f"Redirect to leader {self.leader_id}")
        index = len(self.log)
        entry = raft_log_pb2.LogEntry(command=request.command, term=self.term, index=index)
        self.log.append(entry)
        print(f"[Leader {self.node_id}] Received client command: {request.command}")
        self.replicate_log()
        return raft_log_pb2.ClientResponse(message="Command replicated")

    def replicate_log(self):
        success_count = 1  # Leader itself
        for peer_addr in self.peers:
            try:
                channel = grpc.insecure_channel(peer_addr)
                stub = raft_log_pb2_grpc.RaftLogServiceStub(channel)
                request = raft_log_pb2.AppendEntriesRequest(
                    term=self.term,
                    leader_id=self.node_id,
                    entries=self.log,
                    commit_index=len(self.log) - 1
                )
                response = stub.AppendEntries(request)
                if response.success:
                    success_count += 1
            except Exception as e:
                print(f"Failed to contact {peer_addr}: {e}")

        if success_count > (len(self.peers) + 1) // 2:
            self.commit_index = len(self.log) - 1
            print(f"[Leader {self.node_id}] Committed up to index {self.commit_index}")

def serve(node_id, port, peer_ports):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    peers = [f"node{i}:{p}" for i, p in enumerate(peer_ports, 1) if str(p) != port]
    raft_node = RaftNode(node_id, peers)
    if node_id == "node1":
        raft_node.is_leader = True
        raft_node.term = 1
        raft_node.leader_id = node_id
    raft_log_pb2_grpc.add_RaftLogServiceServicer_to_server(raft_node, server)
    server.add_insecure_port(f"[::]:{port}")
    print(f"[Node {node_id}] Starting Raft log server on port {port}")
    server.start()
    server.wait_for_termination()

if __name__ == "__main__":
    node_id = os.environ.get("NODE_ID")
    port = os.environ.get("PORT")
    peer_ports = [5001, 5002, 5003, 5004, 5005]
    serve(node_id, port, peer_ports)
