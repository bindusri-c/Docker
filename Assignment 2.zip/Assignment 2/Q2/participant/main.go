package main

import (
    "context"
    "log"
    "net"
    "os"

    pb "q2decision/proto/two_pc"
    "google.golang.org/grpc"
)

type server struct {
    pb.UnimplementedDecisionPhaseServer
}

func (s *server) SendDecision(ctx context.Context, msg *pb.DecisionRequest) (*pb.Ack, error) {
    nodeID := os.Getenv("NODE_ID")
    log.Printf("Phase Decision of Node %s runs RPC SendDecision called by Phase Decision of Node coordinator", nodeID)
    log.Printf("Node %s received decision: %s", nodeID, msg.Decision.String())

    return &pb.Ack{
        ParticipantId: nodeID,
        Message:       "ACK",
    }, nil
}

func main() {
    port := os.Getenv("PORT")
    if port == "" {
        port = "50051"
    }

    lis, err := net.Listen("tcp", ":"+port)
    if err != nil {
        log.Fatalf("failed to listen: %v", err)
    }

    s := grpc.NewServer()
    pb.RegisterDecisionPhaseServer(s, &server{})
    log.Printf("Participant Node %s listening on port %s", os.Getenv("NODE_ID"), port)
    if err := s.Serve(lis); err != nil {
        log.Fatalf("failed to serve: %v", err)
    }
}
