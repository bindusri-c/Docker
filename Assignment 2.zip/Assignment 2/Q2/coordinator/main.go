package main

import (
    "context"
    "log"
    "os"
    "time"

    pb "q2decision/proto/two_pc"
    "google.golang.org/grpc"
)

var participants = []string{
    "participant1:50051",
    "participant2:50052",
    "participant3:50053",
    "participant4:50054",
}

func main() {
    decision := pb.DecisionRequest_GLOBAL_COMMIT
    transactionID := "tx123"

    for _, addr := range participants {
        go sendDecision(addr, transactionID, decision)
    }

    time.Sleep(3 * time.Second)
}

func sendDecision(addr, txID string, decision pb.DecisionRequest_Decision) {
    conn, err := grpc.Dial(addr, grpc.WithInsecure())
    if err != nil {
        log.Printf("Failed to connect to %s: %v", addr, err)
        return
    }
    defer conn.Close()

    client := pb.NewDecisionPhaseClient(conn)
    nodeID := os.Getenv("NODE_ID")

    req := &pb.DecisionRequest{
        TransactionId: txID,
        Decision:      decision,
    }

    log.Printf("Phase Decision of Node %s sends RPC SendDecision to Phase Decision of Node %s", nodeID, addr)

    res, err := client.SendDecision(context.Background(), req)
    if err != nil {
        log.Printf("Error in SendDecision to %s: %v", addr, err)
        return
    }

    log.Printf("Received ACK from %s: %s", addr, res.Message)
}
