## Consensus Algorithms (2PC & Raft) – Assignment 2

## Team Members
- Pranit Manda – 1002041394
- Nagineni Bindu Srivalli – 1002175940

---

## Overview

This project implements two core distributed consensus algorithms using gRPC and Docker:

| Part | Algorithm            | Language | Description                            |
|------|----------------------|----------|----------------------------------------|
| Q1   | 2PC – Voting Phase   | Python   | Nodes vote to commit or abort          |
| Q2   | 2PC – Decision Phase | Go       | Coordinator decides and informs nodes  |
| Q3   | Raft Leader Election | Go       | Leader election using heartbeat & vote |
| Q4   | Raft Log Replication | Python   | Log sync between leader and followers  |
| Q5   | Test Cases           | Shell    | Run test cases and collect logs        |

---

## Prerequisites

- Docker & Docker Compose
- Python 3.9+
- Go 1.22+
- gRPC tools (`protoc`, `grpcio-tools`, `protoc-gen-go`, etc.)

---

## How to Run

### Q1 & Q2 – Two-Phase Commit

```bash
cd Q1 or Q2/
docker-compose build
docker-compose up
```

### Q3 – Raft Leader Election (Go)

```bash
cd Q3/
docker-compose build
docker-compose up
```

### Q4 – Raft Log Replication (Python)

```bash
cd Q4/
docker-compose build
docker-compose up
```

### Send Client Command to Leader

```bash
docker exec -it node1 python3 -c "
import grpc, raft_log_pb2, raft_log_pb2_grpc
channel = grpc.insecure_channel('node1:5001')
stub = raft_log_pb2_grpc.RaftLogServiceStub(channel)
print(stub.ClientCommand(raft_log_pb2.ClientRequest(command='SET x=10')))
"
```

---

### Q5 – Run Test Cases

```bash
cd Q5/
bash run_q5_tests.sh
```

Log files saved in `logs/`.

---

## Folder Structure

```
Assignment_2/
├── Q1
├── Q2
├── Q3
├── Q4
├── Q5
├── Final_Report_Assignment_2.pdf
└── README.md
```

---